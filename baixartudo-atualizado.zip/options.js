(async function(){
  var $ = function(i){ return document.getElementById(i); }, c = await BT.config();
  $("servidor").value = c.servidor; $("qualidade").value = c.qualidade; $("botaoYoutube").checked = c.botaoYoutube;
  $("salvar").onclick = async function(){
    var s = ($("servidor").value.trim() || BT.PADRAO.servidor).replace(/\/+$/, "");
    try { var o = new URL(s).origin; } catch(e){ $("aviso").textContent = "Endereço inválido."; return; }
    if(s !== BT.PADRAO.servidor){
      var ok = await chrome.permissions.request({ origins: [o + "/*"] });
      if(!ok){ $("aviso").textContent = "Sem permissão para esse servidor."; return; }
    }
    await chrome.storage.sync.set({ servidor: s, qualidade: $("qualidade").value, botaoYoutube: $("botaoYoutube").checked });
    $("aviso").textContent = "✅ Salvo!";
  };
})();
