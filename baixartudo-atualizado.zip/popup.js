(async function(){
  var $ = function(i){ return document.getElementById(i); };
  var cfg = await BT.config(), titulo = "";
  $("qualidade").value = cfg.qualidade; $("semMarca").checked = cfg.semMarca;
  // opções removidas do popup
  function msg(tipo, t){ $("status").className = "status " + tipo; $("status").textContent = t; }
  function mostrarInfo(link){
    var det = BT.detectar(link);
    $("ttLinha").hidden = !(det && det.site === "TikTok");
    return det;
  }
  $("url").addEventListener("input", function(){ mostrarInfo($("url").value.trim()); });
  $("semMarca").onchange = function(){ chrome.storage.sync.set({ semMarca: $("semMarca").checked }); };
  var tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0] || {};
  var det = tab.url ? mostrarInfo(tab.url) : null;
  if(det){
    $("url").value = det.url; $("video").hidden = false; $("site").textContent = det.site;
    titulo = (tab.title || "").replace(/^\(\d+\)\s*/, "").replace(/ [-|] (YouTube|TikTok|Instagram|Facebook|Reddit|Pinterest)$/i, "").replace(/ \/ X$/, "");
    $("titulo").textContent = titulo || det.url;
    if(det.site === "YouTube"){
      try {
        var o = await (await fetch("https://www.youtube.com/oembed?format=json&url=" + encodeURIComponent(det.url))).json();
        if(o.title){ titulo = o.title; $("titulo").textContent = o.title; }
        if(o.thumbnail_url){ $("thumb").src = o.thumbnail_url; $("thumb").hidden = false; }
      } catch(e){
        var v = new URL(det.url).searchParams.get("v") || (det.url.match(/shorts\/([\w-]+)/) || [])[1];
        if(v){ $("thumb").src = "https://i.ytimg.com/vi/" + v + "/mqdefault.jpg"; $("thumb").hidden = false; }
      }
    } else if(tab.favIconUrl){ $("thumb").src = tab.favIconUrl; $("thumb").style.objectFit = "contain"; $("thumb").hidden = false; }
  } else { $("nada").hidden = false; }

  $("baixar").onclick = async function(){
    var link = $("url").value.trim(); $("itens").innerHTML = "";
    if(!/^https?:\/\//i.test(link)){ msg("erro", "Coloque um link que comece com http:// ou https://"); return; }
    var q = $("qualidade").value, audio = q === "audio";
    if(link !== (det && det.url)) titulo = "";
    chrome.storage.sync.set({ qualidade: q });
    $("baixar").disabled = true; msg("carregando", "⏳ Procurando o arquivo...");
    try {
      var d = await BT.pedir(link, { audio: audio, qualidade: q });
      if(d.status === "tunnel" || d.status === "redirect"){
        await BT.baixar(d.url, BT.nomeDe(d, titulo, null, audio ? "audio" : "video"));
        msg("ok", "✅ Pronto! O download começou.");
      } else if(d.status === "picker" || d.status === "local-processing"){
        var itens = d.status === "picker" ? (d.picker || []) : (d.tunnel || []).map(function(u){ return { url: u, type: "video" }; });
        msg("ok", "Achei " + itens.length + " itens. Baixe cada um:");
        if(d.audio) itens.push({ url: d.audio, type: "audio" });
        itens.forEach(function(it, i){
          var box = document.createElement("div"); box.className = "item";
          if(it.thumb){ var im = document.createElement("img"); im.src = it.thumb; box.appendChild(im); }
          var b = document.createElement("button");
          b.textContent = "⬇ " + (it.type === "photo" ? "Foto " : it.type === "gif" ? "GIF " : it.type === "audio" ? "Áudio " : "Vídeo ") + (i + 1);
          b.onclick = function(){ BT.baixar(it.url, BT.nomeDe(null, titulo, i, it.type)); b.textContent = "✓ Baixando"; };
          box.appendChild(b); $("itens").appendChild(box);
        });
      } else msg("erro", "Resposta que não conheço: " + d.status);
    } catch(e){ msg("erro", "⚠️ " + e.message); }
    $("baixar").disabled = false;
  };
})();
