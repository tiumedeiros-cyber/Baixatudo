importScripts("common.js");
chrome.runtime.onInstalled.addListener(function(){
  chrome.contextMenus.removeAll(function(){
    chrome.contextMenus.create({ id: "bt-link", title: "Baixar com Baixa Tudo", contexts: ["link", "video"] });
    chrome.contextMenus.create({ id: "bt-pagina", title: "Baixar com Baixa Tudo", contexts: ["page"] });
  });
});
function avisar(tabId, texto){
  chrome.action.setBadgeBackgroundColor({ color: texto === "ok" ? "#19c37d" : "#ff7b7b" });
  chrome.action.setBadgeText({ text: texto === "ok" ? "✓" : "!", tabId: tabId });
  chrome.action.setTitle({ title: texto === "ok" ? "Baixa Tudo: download começou" : "Baixa Tudo: " + texto, tabId: tabId });
  setTimeout(function(){ chrome.action.setBadgeText({ text: "", tabId: tabId }); }, 6000);
}
async function baixarDireto(link, titulo, tabId){
  var d = await BT.pedir(link, {});
  if(d.status === "tunnel" || d.status === "redirect"){ await BT.baixar(d.url, BT.nomeDe(d, titulo)); }
  else if(d.status === "picker"){ for(var i = 0; i < (d.picker || []).length; i++){ var it = d.picker[i]; await BT.baixar(it.url, BT.nomeDe(null, titulo, i, it.type)); } }
  else if(d.status === "local-processing"){ throw new Error("Esse link veio em partes. Abra o ícone do Baixa Tudo para baixar."); }
  else throw new Error("Resposta que não conheço: " + d.status);
}
chrome.contextMenus.onClicked.addListener(function(info, tab){
  var link = info.menuItemId === "bt-link" ? (info.linkUrl || info.srcUrl) : (info.pageUrl || (tab && tab.url));
  var tabId = tab && tab.id;
  baixarDireto(link, info.menuItemId === "bt-pagina" && tab ? tab.title : null, tabId)
    .then(function(){ avisar(tabId, "ok"); })
    .catch(function(e){ avisar(tabId, e.message); });
});
chrome.runtime.onMessage.addListener(function(msg, sender, responder){
  if(msg && msg.tipo === "baixar"){
    baixarDireto(msg.url, msg.titulo, sender.tab && sender.tab.id)
      .then(function(){ responder({ ok: true }); })
      .catch(function(e){ responder({ ok: false, erro: e.message }); });
    return true;
  }
});
