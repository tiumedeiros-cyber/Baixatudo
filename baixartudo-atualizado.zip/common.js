// Compartilhado entre popup, background e opções
var BT = (function(){
  var PADRAO = { servidor: "https://baixartudo.me", qualidade: "1080", botaoYoutube: true, semMarca: true };
  function config(){ return chrome.storage.sync.get(PADRAO); }
  var SITES = [
    [/(^|\.)youtube\.com$/, function(u){ return /^\/(watch|shorts\/|live\/)/.test(u.pathname) && (u.searchParams.get("v") || /^\/(shorts|live)\/[\w-]+/.test(u.pathname)); }, "YouTube"],
    [/^youtu\.be$/, function(u){ return u.pathname.length > 1; }, "YouTube"],
    [/(^|\.)(x|twitter)\.com$/, function(u){ return /\/status\/\d+/.test(u.pathname); }, "X"],
    [/(^|\.)instagram\.com$/, function(u){ return /^\/(reels?|p|tv|stories)\//.test(u.pathname); }, "Instagram"],
    [/(^|\.)tiktok\.com$/, function(u){ return /\/video\/\d+|\/photo\/\d+/.test(u.pathname) || /^v[mt]\./.test(u.hostname); }, "TikTok"],
    [/(^|\.)(facebook\.com|fb\.watch)$/, function(u){ return /\/(videos?|reel|watch|share)/.test(u.pathname) || u.hostname === "fb.watch"; }, "Facebook"],
    [/(^|\.)(pinterest\.[a-z.]+|pin\.it)$/, function(u){ return /\/pin\//.test(u.pathname) || u.hostname === "pin.it"; }, "Pinterest"],
    [/(^|\.)(reddit\.com|redd\.it)$/, function(u){ return /\/comments\/|\/s\//.test(u.pathname) || u.hostname.endsWith("redd.it"); }, "Reddit"],
    [/(^|\.)vimeo\.com$/, function(u){ return /\/\d+/.test(u.pathname); }, "Vimeo"],
    [/(^|\.)(twitch\.tv)$/, function(u){ return /\/clip\/|clips\./.test(u.href); }, "Twitch"],
    [/(^|\.)soundcloud\.com$/, function(u){ return u.pathname.split("/").length >= 3; }, "SoundCloud"],
    [/(^|\.)(bsky\.app)$/, function(u){ return /\/post\//.test(u.pathname); }, "Bluesky"],
    [/(^|\.)(dailymotion\.com|dai\.ly)$/, function(u){ return /\/video\//.test(u.pathname) || u.hostname === "dai.ly"; }, "Dailymotion"],
    [/(^|\.)(streamable\.com|tumblr\.com|vk\.com|ok\.ru|rutube\.ru|loom\.com|bilibili\.com|snapchat\.com)$/, function(){ return true; }, "Vídeo"]
  ];
  function detectar(href){
    try { var u = new URL(href); } catch(e){ return null; }
    if(!/^https?:$/.test(u.protocol)) return null;
    var h = u.hostname.replace(/^(www|m|mobile)\./, "");
    for(var i = 0; i < SITES.length; i++){
      if(SITES[i][0].test(h) && SITES[i][1](u)) return { url: href, site: SITES[i][2] };
    }
    return null;
  }
  var ERROS = {
    "error.api.link.invalid": "Esse link não parece válido. Confira e tente de novo.",
    "error.api.link.unsupported": "Esse site não é aceito pelo motor.",
    "error.api.service.unsupported": "Esse site não é aceito pelo motor.",
    "error.api.service.disabled": "Esse site está desligado no motor.",
    "error.api.fetch.empty": "Não achei nada pra baixar nesse link. Ele é público?",
    "error.api.fetch.fail": "O site não deixou o motor pegar esse arquivo. Tente de novo.",
    "error.api.fetch.critical": "O site respondeu errado. Tente de novo daqui a pouco.",
    "error.api.content.too_long": "Esse vídeo é longo demais.",
    "error.api.content.video.unavailable": "Esse vídeo não está disponível.",
    "error.api.content.video.private": "Esse vídeo é privado.",
    "error.api.content.video.age": "Esse vídeo tem trava de idade.",
    "error.api.content.video.live": "Não dá pra baixar transmissão ao vivo.",
    "error.api.content.post.private": "Esse post é privado.",
    "error.api.content.post.age": "Esse post tem trava de idade.",
    "error.api.rate_exceeded": "Muitos pedidos seguidos. Espere um minuto.",
    "error.api.invalid_body": "O motor não entendeu o pedido."
  };
  function erroAmigavel(c){
    c = c || "";
    if(ERROS[c]) return ERROS[c];
    if(c.indexOf("youtube") >= 0) return "O YouTube bloqueou este vídeo no motor. Tente de novo mais tarde.";
    if(c.indexOf("auth") >= 0) return "O motor recusou o acesso. Avise o John.";
    return "Algo deu errado (" + (c || "sem código") + "). Tente de novo.";
  }
  // Mesmo pedido que o site faz (index.html): POST {servidor}/api/
  async function pedir(link, opc){
    var cfg = await config();
    var corpo = { url: link, downloadMode: opc.audio ? "audio" : "auto", filenameStyle: "pretty" };
    if(opc.audio) corpo.audioFormat = "mp3"; else corpo.videoQuality = opc.qualidade || cfg.qualidade;
    var ctrl = new AbortController(); var t = setTimeout(function(){ ctrl.abort(); }, 60000);
    try {
      var r = await fetch(cfg.servidor.replace(/\/+$/, "") + "/api/", {
        method: "POST", signal: ctrl.signal,
        headers: { "Accept": "application/json", "Content-Type": "application/json" },
        body: JSON.stringify(corpo)
      });
      var d = await r.json();
    } catch(e){
      throw new Error("Não consegui falar com o servidor. O motor pode estar dormindo — abra o site do Baixa Tudo e confira.");
    } finally { clearTimeout(t); }
    if(!d || !d.status) throw new Error("Resposta estranha do motor.");
    if(d.status === "error") throw new Error(erroAmigavel(d.error && d.error.code));
    contar(cfg.servidor, link, corpo.downloadMode);
    return d;
  }
  // conta o download no contador do site (não atrapalha se falhar)
  function siteDe(u){
    var h = ""; try { h = new URL(u).hostname.toLowerCase().replace(/^(www|m|music|vm)\./, ""); } catch(e){}
    var m = { "youtu.be":"youtube", "youtube.com":"youtube", "instagram.com":"instagram", "tiktok.com":"tiktok", "x.com":"twitter", "twitter.com":"twitter", "facebook.com":"facebook", "fb.watch":"facebook", "reddit.com":"reddit", "pinterest.com":"pinterest", "pin.it":"pinterest", "soundcloud.com":"soundcloud", "vimeo.com":"vimeo", "twitch.tv":"twitch", "bsky.app":"bluesky", "threads.net":"threads", "dailymotion.com":"dailymotion" };
    if(m[h]) return m[h]; var p = h.split("."); return p.length > 1 ? p[p.length - 2] : "outro";
  }
  function contar(servidor, link, tipo){
    try {
      fetch(servidor.replace(/\/+$/, "") + "/api/contador/hit", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ service: siteDe(link), type: tipo, ts: Date.now(), origem: "extensao" }) }).catch(function(){});
    } catch(e){}
  }
  function limparNome(n){ return (n || "").replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 150); }
  function nomeDe(d, base, i, tipo){
    if(d && d.filename && i == null) return limparNome(d.filename);
    var ext = tipo === "photo" ? "jpg" : tipo === "gif" ? "gif" : tipo === "audio" ? "mp3" : "mp4";
    return limparNome((base || "baixa-tudo") + (i != null ? " (" + (i + 1) + ")" : "")) + "." + ext;
  }
  function baixar(url, nome){
    return chrome.downloads.download({ url: url, filename: nome ? "Baixa Tudo/" + nome : undefined, conflictAction: "uniquify" });
  }
  return { PADRAO: PADRAO, config: config, detectar: detectar, pedir: pedir, nomeDe: nomeDe, baixar: baixar, erroAmigavel: erroAmigavel };
})();
